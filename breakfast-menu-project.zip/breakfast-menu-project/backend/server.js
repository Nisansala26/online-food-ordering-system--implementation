
const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;


app.use(cors());
app.use(express.json());
app.use(express.static('public'));


const db = new sqlite3.Database('./breakfast_menu.db', (err) => {
  if (err) {
    console.error('Error opening database:', err);
  } else {
    console.log('Connected to SQLite database');
    initializeDatabase();
  }
});


function initializeDatabase() {
  
  db.run(`CREATE TABLE IF NOT EXISTS menu_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    image_url TEXT,
    price_small INTEGER,
    price_medium INTEGER,
    price_large INTEGER,
    calories TEXT,
    category TEXT DEFAULT 'breakfast',
    available BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  
  db.run(`CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_name TEXT,
    customer_email TEXT,
    customer_phone TEXT,
    total_amount INTEGER NOT NULL,
    status TEXT DEFAULT 'pending',
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    delivery_address TEXT,
    notes TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    menu_item_id INTEGER NOT NULL,
    item_name TEXT NOT NULL,
    size TEXT,
    quantity INTEGER NOT NULL,
    price INTEGER NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (menu_item_id) REFERENCES menu_items(id)
  )`);

  
  db.run(`CREATE TABLE IF NOT EXISTS cart (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    menu_item_id INTEGER NOT NULL,
    item_name TEXT NOT NULL,
    size TEXT,
    quantity INTEGER DEFAULT 1,
    price INTEGER NOT NULL,
    added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (menu_item_id) REFERENCES menu_items(id)
  )`);

  
  seedMenuData();
}


function seedMenuData() {
  db.get("SELECT COUNT(*) as count FROM menu_items", (err, row) => {
    if (row.count === 0) {
      const menuItems = [
        ['Rice and curry', 'Steamed rice with spicy chicken curry, dhal and veggies', 'Rice_and_Curry.jpg', 400, 550, 750, '450-650'],
        ['Milk Rice', 'Traditional srilankan dish rice with milk', 'Milk_Rice.jpg', 250, null, null, '300-350'],
        ['Pol Roti', 'Pol roti with grated coconut and flour', 'Pol_Roti.png', 150, null, null, '200-250'],
        ['Hoppers', 'made from fermented rice flour', 'Hoppers.jpg', 60, null, 120, '70-90'],
        ['Fried Rice', 'Fried rice with scrambled egg and veggies', 'Fried_Rice.jpg', 500, 700, 900, '400-700'],
        ['String Hoppers', 'soft rice flour noodles', 'String_Hoppers.jpg', 180, 200, 250, '150-250'],
        ['Short Eats', 'rolls, pastrys cutlets filled with vegetable and meats', 'Short_Eats.jfif', 70, null, 100, '150-200'],
        ['Sandwiches', 'Fresh made with egg & veggies', 'Sandwiches.jfif', 150, null, 200, '250-350'],
        ['Pancakes', 'Soft rolled pancakes with filled sweet coconut', 'Pancakes.jfif', 100, 150, 200, '180-300'],
        ['Hot Beverage', 'Beverages with hot', 'Hot_Beverage.png', 200, 300, 450, '50-150'],
        ['Cold Beverage', 'Fresh beverages with fresh and cold', 'Cold_Beverage.jpg', 250, 320, 400, '100-200']
      ];

      const stmt = db.prepare(`INSERT INTO menu_items 
        (name, description, image_url, price_small, price_medium, price_large, calories) 
        VALUES (?, ?, ?, ?, ?, ?, ?)`);

      menuItems.forEach(item => {
        stmt.run(item);
      });

      stmt.finalize();
      console.log('Menu data seeded successfully');
    }
  });
}


app.get('/api/menu', (req, res) => {
  db.all('SELECT * FROM menu_items WHERE available = 1 ORDER BY id', (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json({ menu_items: rows });
  });
});


app.get('/api/menu/:id', (req, res) => {
  db.get('SELECT * FROM menu_items WHERE id = ?', [req.params.id], (err, row) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    if (!row) {
      res.status(404).json({ error: 'Menu item not found' });
      return;
    }
    res.json({ menu_item: row });
  });
});


app.post('/api/cart/add', (req, res) => {
  const { session_id, menu_item_id, item_name, size, quantity, price } = req.body;

  if (!session_id || !menu_item_id || !item_name || !price) {
    res.status(400).json({ error: 'Missing required fields' });
    return;
  }

  
  db.get(
    'SELECT * FROM cart WHERE session_id = ? AND menu_item_id = ? AND size = ?',
    [session_id, menu_item_id, size || 'small'],
    (err, row) => {
      if (err) {
        res.status(500).json({ error: err.message });
        return;
      }

      if (row) {
       
        db.run(
          'UPDATE cart SET quantity = quantity + ? WHERE id = ?',
          [quantity || 1, row.id],
          function(err) {
            if (err) {
              res.status(500).json({ error: err.message });
              return;
            }
            res.json({ message: 'Cart updated', cart_id: row.id });
          }
        );
      } else {
        
        db.run(
          `INSERT INTO cart (session_id, menu_item_id, item_name, size, quantity, price) 
           VALUES (?, ?, ?, ?, ?, ?)`,
          [session_id, menu_item_id, item_name, size || 'small', quantity || 1, price],
          function(err) {
            if (err) {
              res.status(500).json({ error: err.message });
              return;
            }
            res.json({ message: 'Item added to cart', cart_id: this.lastID });
          }
        );
      }
    }
  );
});


app.get('/api/cart/:session_id', (req, res) => {
  db.all('SELECT * FROM cart WHERE session_id = ?', [req.params.session_id], (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    
    const total = rows.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    res.json({ cart_items: rows, total: total });
  });
});


app.put('/api/cart/:id', (req, res) => {
  const { quantity } = req.body;

  if (quantity < 1) {
    res.status(400).json({ error: 'Quantity must be at least 1' });
    return;
  }

  db.run('UPDATE cart SET quantity = ? WHERE id = ?', [quantity, req.params.id], function(err) {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json({ message: 'Cart updated' });
  });
});


app.delete('/api/cart/:id', (req, res) => {
  db.run('DELETE FROM cart WHERE id = ?', [req.params.id], function(err) {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json({ message: 'Item removed from cart' });
  });
});


app.delete('/api/cart/clear/:session_id', (req, res) => {
  db.run('DELETE FROM cart WHERE session_id = ?', [req.params.session_id], function(err) {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json({ message: 'Cart cleared' });
  });
});


app.post('/api/orders', (req, res) => {
  const { customer_name, customer_email, customer_phone, session_id, delivery_address, notes } = req.body;

  
  db.all('SELECT * FROM cart WHERE session_id = ?', [session_id], (err, cartItems) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }

    if (cartItems.length === 0) {
      res.status(400).json({ error: 'Cart is empty' });
      return;
    }

    const total_amount = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    
    db.run(
      `INSERT INTO orders (customer_name, customer_email, customer_phone, total_amount, delivery_address, notes) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [customer_name, customer_email, customer_phone, total_amount, delivery_address, notes],
      function(err) {
        if (err) {
          res.status(500).json({ error: err.message });
          return;
        }

        const orderId = this.lastID;

        
        const stmt = db.prepare(`INSERT INTO order_items 
          (order_id, menu_item_id, item_name, size, quantity, price) 
          VALUES (?, ?, ?, ?, ?, ?)`);

        cartItems.forEach(item => {
          stmt.run([orderId, item.menu_item_id, item.item_name, item.size, item.quantity, item.price]);
        });

        stmt.finalize();

        
        db.run('DELETE FROM cart WHERE session_id = ?', [session_id]);

        res.json({ 
          message: 'Order created successfully', 
          order_id: orderId,
          total_amount: total_amount 
        });
      }
    );
  });
});


app.get('/api/orders/:id', (req, res) => {
  db.get('SELECT * FROM orders WHERE id = ?', [req.params.id], (err, order) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }

    if (!order) {
      res.status(404).json({ error: 'Order not found' });
      return;
    }

    db.all('SELECT * FROM order_items WHERE order_id = ?', [req.params.id], (err, items) => {
      if (err) {
        res.status(500).json({ error: err.message });
        return;
      }

      res.json({ order: order, items: items });
    });
  });
});


app.get('/api/orders', (req, res) => {
  const status = req.query.status;
  let query = 'SELECT * FROM orders ORDER BY order_date DESC';
  let params = [];

  if (status) {
    query = 'SELECT * FROM orders WHERE status = ? ORDER BY order_date DESC';
    params = [status];
  }

  db.all(query, params, (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json({ orders: rows });
  });
});


app.put('/api/orders/:id/status', (req, res) => {
  const { status } = req.body;

  const validStatuses = ['pending', 'confirmed', 'preparing', 'ready', 'delivered', 'cancelled'];
  if (!validStatuses.includes(status)) {
    res.status(400).json({ error: 'Invalid status' });
    return;
  }

  db.run('UPDATE orders SET status = ? WHERE id = ?', [status, req.params.id], function(err) {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json({ message: 'Order status updated' });
  });
});


app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});


process.on('SIGINT', () => {
  db.close((err) => {
    if (err) {
      console.error(err.message);
    }
    console.log('Database connection closed');
    process.exit(0);
  });
});